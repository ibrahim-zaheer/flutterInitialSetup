//  email:
//  imageProfile:
//  name:
//  phoneNumber:
//  age:
//  city:
//  country:
//  lookingForInAPartner:
//  profileHeading:
//  publishedDateTime:


//  height:
//  weight:
//  bodyType:


//  drink:
//  smoke:
//  maritalStatus:
//  haveChildren:
//  numberOfChildren:
//  profession:
//  income:
//  livingSituation:
//  willingToRelocate:
//  relationshipYouAreLookingFor:


//  nationality:
//  education:
//  language:
//  religion:
//  ethnicity:
